import boto3
import json
import os
import pymysql
import tempfile

def handler(event, context):
    print(f"Received event: {json.dumps(event)}")
    
    s3 = boto3.client('s3')
    elbv2 = boto3.client('elbv2')
    secrets = boto3.client('secretsmanager')
    
    # Environment variables
    bucket_name = os.environ['SQL_BUCKET_NAME']
    listener_arn = os.environ['LISTENER_ARN']
    blue_tg_arn = os.environ['BLUE_TG_ARN']
    green_tg_arn = os.environ['GREEN_TG_ARN']
    blue_rds_host = os.environ['BLUE_RDS_HOST']
    green_rds_host = os.environ['GREEN_RDS_HOST']
    db_name = os.environ['DB_NAME']
    secret_arn = os.environ['SECRET_ARN']
    
    # 1. Get latest .sql file from S3
    print(f"Listing objects in bucket: {bucket_name}")
    response = s3.list_objects_v2(Bucket=bucket_name, Prefix='')
    sql_files = [obj for obj in response.get('Contents', []) if obj['Key'].endswith('.sql')]
    
    if not sql_files:
        return {'statusCode': 404, 'body': 'No .sql files found'}
    
    latest_file = max(sql_files, key=lambda x: x['LastModified'])
    print(f"Latest SQL file: {latest_file['Key']}")
    
    # 2. Determine which environment has 0 weight
    rules = elbv2.describe_rules(ListenerArn=listener_arn)['Rules']
    default_rule = next((r for r in rules if r['IsDefault']), None)
    
    if not default_rule:
        return {'statusCode': 500, 'body': 'No default rule found'}
    
    # Find target group weights
    target_groups = default_rule['Actions'][0].get('ForwardConfig', {}).get('TargetGroups', [])
    
    inactive_env = None
    rds_host = None
    
    for tg in target_groups:
        if tg['TargetGroupArn'] == blue_tg_arn and tg.get('Weight', 0) == 0:
            inactive_env = 'blue'
            rds_host = blue_rds_host
            break
        elif tg['TargetGroupArn'] == green_tg_arn and tg.get('Weight', 0) == 0:
            inactive_env = 'green'
            rds_host = green_rds_host
            break
    
    if not inactive_env:
        # Check if listener uses simple forward (no weights)
        print("No weighted routing found, using Blue RDS as default")
        inactive_env = 'blue'
        rds_host = blue_rds_host
    
    print(f"Inactive environment: {inactive_env}, RDS Host: {rds_host}")
    
    # 3. Get database credentials from Secrets Manager
    secret_value = secrets.get_secret_value(SecretId=secret_arn)
    secret = json.loads(secret_value['SecretString'])
    db_user = secret['db_username']
    db_password = secret['db_password']
    
    # 4. Download SQL file
    with tempfile.NamedTemporaryFile(mode='w', suffix='.sql', delete=False) as tmp:
        s3.download_file(bucket_name, latest_file['Key'], tmp.name)
        sql_file_path = tmp.name
    
    # 5. Execute SQL on RDS
    print(f"Connecting to RDS: {rds_host}")
    try:
        conn = pymysql.connect(
            host=rds_host,
            user=db_user,
            password=db_password,
            database=db_name,
            connect_timeout=30
        )
        
        with open(sql_file_path, 'r') as f:
            sql_content = f.read()
        
        cursor = conn.cursor()
        # Execute each statement separately
        for statement in sql_content.split(';'):
            statement = statement.strip()
            if statement:
                cursor.execute(statement)
        
        conn.commit()
        cursor.close()
        conn.close()
        
        print(f"SQL import completed successfully to {inactive_env} environment")
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'environment': inactive_env,
                'file': latest_file['Key'],
                'status': 'success'
            })
        }
    except Exception as e:
        print(f"Error executing SQL: {str(e)}")
        return {'statusCode': 500, 'body': str(e)}
