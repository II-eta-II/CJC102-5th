import boto3
import json
import os
import pymysql
import tempfile

def handler(event, context):
    print(f"Received event: {json.dumps(event)}")
    
    s3 = boto3.client('s3')
    elbv2 = boto3.client('elbv2')
    secrets = boto3.client('secretsmanager')
    lambda_client = boto3.client('lambda')
    
    # Environment variables
    bucket_name = os.environ['SQL_BUCKET_NAME']
    listener_arn = os.environ['LISTENER_ARN']
    blue_tg_arn = os.environ['BLUE_TG_ARN']
    green_tg_arn = os.environ['GREEN_TG_ARN']
    blue_rds_host = os.environ['BLUE_RDS_HOST']
    green_rds_host = os.environ['GREEN_RDS_HOST']
    db_name = os.environ['DB_NAME']
    secret_arn = os.environ['SECRET_ARN']
    ecs_deploy_lambda_arn = os.environ.get('ECS_DEPLOY_LAMBDA_ARN', '')
    
    # 1. Get latest .sql file from S3
    print(f"Listing objects in bucket: {bucket_name}")
    response = s3.list_objects_v2(Bucket=bucket_name, Prefix='')
    sql_files = [obj for obj in response.get('Contents', []) if obj['Key'].endswith('.sql')]
    
    if not sql_files:
        return {'statusCode': 404, 'body': 'No .sql files found'}
    
    latest_file = max(sql_files, key=lambda x: x['LastModified'])
    print(f"Latest SQL file: {latest_file['Key']}")
    
    # 2. Determine which environment has 0 weight
    rules = elbv2.describe_rules(ListenerArn=listener_arn)['Rules']
    default_rule = next((r for r in rules if r['IsDefault']), None)
    
    if not default_rule:
        return {'statusCode': 500, 'body': 'No default rule found'}
    
    # Find target group weights
    target_groups = default_rule['Actions'][0].get('ForwardConfig', {}).get('TargetGroups', [])
    
    inactive_env = None
    rds_host = None
    blue_weight = None
    green_weight = None
    
    # Get weights for each target group
    for tg in target_groups:
        if tg['TargetGroupArn'] == blue_tg_arn:
            blue_weight = tg.get('Weight', 0)
        elif tg['TargetGroupArn'] == green_tg_arn:
            green_weight = tg.get('Weight', 0)
    
    print(f"Blue weight: {blue_weight}, Green weight: {green_weight}")
    
    # Determine which environment has weight = 0
    if blue_weight == 0 and green_weight is not None and green_weight > 0:
        inactive_env = 'blue'
        rds_host = blue_rds_host
    elif green_weight == 0 and blue_weight is not None and blue_weight > 0:
        inactive_env = 'green'
        rds_host = green_rds_host
    else:
        # Both have non-zero weight or no weighted routing found
        print("No environment with weight=0 found. Skipping SQL import.")
        return {
            'statusCode': 200,
            'body': json.dumps({
                'status': 'skipped',
                'reason': 'Both environments have non-zero weight or no weighted routing',
                'blue_weight': blue_weight,
                'green_weight': green_weight
            })
        }
    
    print(f"Inactive environment: {inactive_env}, RDS Host: {rds_host}")
    
    # 3. Get database credentials from Secrets Manager
    secret_value = secrets.get_secret_value(SecretId=secret_arn)
    secret = json.loads(secret_value['SecretString'])
    db_user = secret['db_username']
    db_password = secret['db_password']
    
    # 4. Download SQL file
    with tempfile.NamedTemporaryFile(mode='w', suffix='.sql', delete=False) as tmp:
        s3.download_file(bucket_name, latest_file['Key'], tmp.name)
        sql_file_path = tmp.name
    
    # 5. Execute SQL on RDS
    print(f"Connecting to RDS: {rds_host}")
    try:
        # Use CLIENT.MULTI_STATEMENTS to execute multiple SQL statements at once
        from pymysql.constants import CLIENT
        conn = pymysql.connect(
            host=rds_host,
            user=db_user,
            password=db_password,
            database=db_name,
            connect_timeout=30,
            client_flag=CLIENT.MULTI_STATEMENTS
        )
        
        with open(sql_file_path, 'r', encoding='utf-8') as f:
            sql_content = f.read()
        
        cursor = conn.cursor()
        # Execute entire SQL dump as multi-statement
        cursor.execute(sql_content)
        
        # Consume all results to avoid "Commands out of sync" error
        while cursor.nextset():
            pass
        
        conn.commit()
        cursor.close()
        conn.close()
        
        print(f"SQL import completed successfully to {inactive_env} environment")
        
        # 6. Invoke ecs_deploy Lambda (next step in pipeline)
        if ecs_deploy_lambda_arn:
            print(f"Invoking ecs_deploy Lambda: {ecs_deploy_lambda_arn}")
            try:
                lambda_client.invoke(
                    FunctionName=ecs_deploy_lambda_arn,
                    InvocationType='Event',  # Async invoke
                    Payload=json.dumps(event)
                )
                print("ecs_deploy Lambda invoked successfully")
            except Exception as e:
                print(f"Error invoking ecs_deploy Lambda: {e}")
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'environment': inactive_env,
                'file': latest_file['Key'],
                'status': 'success',
                'next_step': 'ecs_deploy'
            })
        }
    except Exception as e:
        print(f"Error executing SQL: {str(e)}")
        return {'statusCode': 500, 'body': str(e)}
