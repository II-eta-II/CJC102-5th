import boto3
import json
import os

def handler(event, context):
    """
    Emergency Rollback Lambda
    
    可在金絲雀部署任何階段觸發，立即將流量切回原環境。
    
    Event 參數:
    - target_env: 'blue' 或 'green' (可選，不指定則自動偵測)
    
    使用方式:
    1. AWS Console: 手動 Test Lambda
    2. CLI: aws lambda invoke --function-name usa-ops-rollback ...
    """
    print(f"Received event: {json.dumps(event)}")
    
    elbv2 = boto3.client('elbv2')
    
    # Environment variables
    listener_arn = os.environ['LISTENER_ARN']
    blue_tg_arn = os.environ['BLUE_TG_ARN']
    green_tg_arn = os.environ['GREEN_TG_ARN']
    
    # Get current weights from listener
    listeners = elbv2.describe_listeners(ListenerArns=[listener_arn])['Listeners']
    if not listeners:
        return {'statusCode': 500, 'body': 'No listener found'}
    
    listener = listeners[0]
    tgs = listener['DefaultActions'][0].get('ForwardConfig', {}).get('TargetGroups', [])
    
    blue_weight = 0
    green_weight = 0
    
    for tg in tgs:
        if tg['TargetGroupArn'] == blue_tg_arn:
            blue_weight = tg.get('Weight', 0)
        elif tg['TargetGroupArn'] == green_tg_arn:
            green_weight = tg.get('Weight', 0)
    
    print(f"Current weights - Blue: {blue_weight}, Green: {green_weight}")
    
    # Determine target environment
    target_env = event.get('target_env')
    
    if not target_env:
        # Auto-detect: rollback to the one with higher weight (the "old" env)
        if blue_weight >= green_weight:
            target_env = 'blue'
        else:
            target_env = 'green'
    
    # Set 100% traffic to target environment
    if target_env == 'blue':
        new_blue_weight = 100
        new_green_weight = 0
    else:
        new_blue_weight = 0
        new_green_weight = 100
    
    print(f"ROLLBACK: Setting traffic to {target_env} (100%)")
    
    elbv2.modify_listener(
        ListenerArn=listener_arn,
        DefaultActions=[{
            'Type': 'forward',
            'ForwardConfig': {
                'TargetGroups': [
                    {'TargetGroupArn': blue_tg_arn, 'Weight': new_blue_weight},
                    {'TargetGroupArn': green_tg_arn, 'Weight': new_green_weight}
                ]
            }
        }]
    )
    
    print(f"Rollback completed successfully to {target_env}")
    
    return {
        'statusCode': 200,
        'body': json.dumps({
            'status': 'rollback_completed',
            'target_environment': target_env,
            'previous_weights': {'blue': blue_weight, 'green': green_weight},
            'new_weights': {'blue': new_blue_weight, 'green': new_green_weight}
        })
    }
