import boto3
import json
import os
import time

def handler(event, context):
    print(f"Received event: {json.dumps(event)}")
    
    elbv2 = boto3.client('elbv2')
    cloudwatch = boto3.client('cloudwatch')
    lambda_client = boto3.client('lambda')
    
    # Environment variables
    listener_arn = os.environ['LISTENER_ARN']
    blue_tg_arn = os.environ['BLUE_TG_ARN']
    green_tg_arn = os.environ['GREEN_TG_ARN']
    canary_enabled = os.environ.get('CANARY_ENABLED', 'true').lower() == 'true'
    pre_deploy_wait = int(os.environ.get('PRE_DEPLOY_WAIT_SEC', '120'))
    canary_pct = int(os.environ.get('CANARY_PERCENTAGE', '10'))
    canary_duration = int(os.environ.get('CANARY_DURATION_SEC', '300'))
    full_deploy_wait = int(os.environ.get('FULL_DEPLOY_WAIT_SEC', '60'))
    alarm_5xx_name = os.environ.get('ALARM_5XX_NAME', '')
    synthetic_lambda_arn = os.environ.get('SYNTHETIC_LAMBDA_ARN', '')
    
    if not canary_enabled:
        print("Canary deployment is disabled. Skipping.")
        return {'statusCode': 200, 'body': json.dumps({'status': 'skipped', 'reason': 'disabled'})}
    
    # Stage 0: Pre-deploy wait - wait for new deployment to be ready
    print(f"Stage 0: Waiting {pre_deploy_wait} seconds for new deployment to be ready...")
    time.sleep(pre_deploy_wait)
    
    # Get inactive environment from event or detect from ALB
    inactive_env = event.get('inactive_env')
    
    if not inactive_env:
        # Detect from ALB weights
        rules = elbv2.describe_rules(ListenerArn=listener_arn)['Rules']
        default_rule = next((r for r in rules if r['IsDefault']), None)
        
        if not default_rule:
            return {'statusCode': 500, 'body': 'No default rule found'}
        
        tgs = default_rule['Actions'][0].get('ForwardConfig', {}).get('TargetGroups', [])
        for tg in tgs:
            if tg['TargetGroupArn'] == blue_tg_arn and tg.get('Weight', 0) == 0:
                inactive_env = 'blue'
                break
            elif tg['TargetGroupArn'] == green_tg_arn and tg.get('Weight', 0) == 0:
                inactive_env = 'green'
                break
    
    if not inactive_env:
        print("No inactive environment found. Skipping canary deployment.")
        return {'statusCode': 200, 'body': json.dumps({'status': 'skipped', 'reason': 'no_inactive_env'})}
    
    print(f"Starting canary deployment for: {inactive_env}")
    
    # Determine target groups
    if inactive_env == 'blue':
        new_tg_arn = blue_tg_arn
        old_tg_arn = green_tg_arn
    else:
        new_tg_arn = green_tg_arn
        old_tg_arn = blue_tg_arn
    
    # Helper function to modify listener default action
    def set_traffic_weights(tg1_arn, tg1_weight, tg2_arn, tg2_weight):
        """Modify listener default action to set traffic weights"""
        elbv2.modify_listener(
            ListenerArn=listener_arn,
            DefaultActions=[{
                'Type': 'forward',
                'ForwardConfig': {
                    'TargetGroups': [
                        {'TargetGroupArn': tg1_arn, 'Weight': tg1_weight},
                        {'TargetGroupArn': tg2_arn, 'Weight': tg2_weight}
                    ]
                }
            }]
        )
    
    def rollback(reason):
        """Rollback to old environment"""
        print(f"ROLLBACK triggered: {reason}")
        set_traffic_weights(old_tg_arn, 100, new_tg_arn, 0)
        return {
            'statusCode': 500,
            'body': json.dumps({
                'status': 'rollback',
                'reason': reason,
                'environment': inactive_env
            })
        }
    
    def check_alarms():
        """Check CloudWatch alarms for errors"""
        if not alarm_5xx_name:
            return None
        
        try:
            response = cloudwatch.describe_alarms(AlarmNames=[alarm_5xx_name])
            for alarm in response.get('MetricAlarms', []):
                if alarm['StateValue'] == 'ALARM':
                    return alarm['AlarmName']
        except Exception as e:
            print(f"Error checking alarms: {e}")
        return None
    
    def check_target_health():
        """Check Target Group health - only 'unhealthy' status triggers rollback"""
        unhealthy_threshold = 0  # Trigger rollback if any unhealthy targets
        
        try:
            response = elbv2.describe_target_health(TargetGroupArn=new_tg_arn)
            targets = response.get('TargetHealthDescriptions', [])
            
            unhealthy_count = 0
            other_states = {}
            
            for target in targets:
                health_state = target.get('TargetHealth', {}).get('State', '')
                if health_state == 'unhealthy':
                    unhealthy_count += 1
                else:
                    # Count other states for logging only
                    other_states[health_state] = other_states.get(health_state, 0) + 1
            
            total_count = len(targets)
            print(f"Target health check - Total: {total_count}, Unhealthy: {unhealthy_count}, Others: {other_states}")
            
            # Only 'unhealthy' status triggers rollback
            if unhealthy_count > unhealthy_threshold:
                return f"Unhealthy targets detected: {unhealthy_count}/{total_count}"
                
        except Exception as e:
            print(f"Error checking target health: {e}")
        
        return None
    
    def invoke_synthetic_traffic():
        """Invoke synthetic traffic Lambda"""
        if not synthetic_lambda_arn:
            print("No synthetic traffic Lambda configured")
            return
        
        try:
            print("Invoking synthetic traffic Lambda...")
            lambda_client.invoke(
                FunctionName=synthetic_lambda_arn,
                InvocationType='Event'  # Async
            )
            print("Synthetic traffic Lambda invoked")
        except Exception as e:
            print(f"Error invoking synthetic traffic: {e}")
    
    # Stage 1: Canary - small percentage to new environment
    print(f"Stage 1: Canary - {canary_pct}% to new environment ({inactive_env})")
    set_traffic_weights(old_tg_arn, 100 - canary_pct, new_tg_arn, canary_pct)
    
    # Invoke synthetic traffic to ensure we have requests
    invoke_synthetic_traffic()
    
    # Wait for canary observation with alarm monitoring
    print(f"Waiting {canary_duration} seconds for canary observation...")
    check_interval = 30  # Check every 30 seconds
    elapsed = 0
    
    while elapsed < canary_duration:
        time.sleep(check_interval)
        elapsed += check_interval
        
        # Check for alarms
        alarm_triggered = check_alarms()
        if alarm_triggered:
            return rollback(f"CloudWatch alarm triggered: {alarm_triggered}")
        
        # Check target health
        health_error = check_target_health()
        if health_error:
            return rollback(f"Target health check failed: {health_error}")
        
        print(f"Canary check at {elapsed}s - All checks passed")
    
    # Stage 2: Full deployment - 100% to new environment
    print(f"Stage 2: Full deployment - 100% to new environment ({inactive_env})")
    set_traffic_weights(old_tg_arn, 0, new_tg_arn, 100)
    
    # Invoke synthetic traffic again for full deployment test
    invoke_synthetic_traffic()
    
    # Wait for full deployment with alarm monitoring
    print(f"Waiting {full_deploy_wait} seconds for full deployment...")
    elapsed = 0
    
    while elapsed < full_deploy_wait:
        time.sleep(min(check_interval, full_deploy_wait - elapsed))
        elapsed += check_interval
        
        # Check for alarms
        alarm_triggered = check_alarms()
        if alarm_triggered:
            return rollback(f"CloudWatch alarm triggered during full deploy: {alarm_triggered}")
        
        # Check target health
        health_error = check_target_health()
        if health_error:
            return rollback(f"Target health check failed during full deploy: {health_error}")
    
    print(f"Canary deployment completed successfully for {inactive_env}")
    
    return {
        'statusCode': 200,
        'body': json.dumps({
            'status': 'deployed',
            'environment': inactive_env,
            'canary_percentage': canary_pct,
            'canary_duration': canary_duration
        })
    }
