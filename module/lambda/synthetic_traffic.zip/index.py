import json
import os
import time
import urllib.request
import urllib.error
import concurrent.futures

def handler(event, context):
    print(f"Received event: {json.dumps(event)}")
    
    # Environment variables
    target_url = os.environ.get('TARGET_URL', '')
    min_requests = int(os.environ.get('MIN_REQUESTS', '100'))
    concurrent_requests = int(os.environ.get('CONCURRENT_REQUESTS', '10'))
    request_interval_ms = int(os.environ.get('REQUEST_INTERVAL_MS', '100'))
    pre_deploy_wait = int(os.environ.get('PRE_DEPLOY_WAIT_SEC', '120'))
    
    # Override from event if provided
    target_url = event.get('target_url', target_url)
    min_requests = event.get('min_requests', min_requests)
    
    if not target_url:
        return {'statusCode': 400, 'body': json.dumps({'error': 'TARGET_URL not configured'})}
    
    # Stage 0: Pre-deploy wait - same as canary
    print(f"Stage 0: Waiting {pre_deploy_wait} seconds for new deployment to be ready...")
    time.sleep(pre_deploy_wait)
    
    print(f"Starting synthetic traffic test")
    print(f"Target URL: {target_url}")
    print(f"Minimum requests: {min_requests}")
    print(f"Concurrent requests: {concurrent_requests}")
    
    success_count = 0
    error_4xx = 0
    error_5xx = 0
    other_errors = 0
    
    def make_request(i):
        try:
            req = urllib.request.Request(target_url, headers={'User-Agent': 'SyntheticTrafficLambda/1.0'})
            with urllib.request.urlopen(req, timeout=30) as response:
                status = response.getcode()
                return ('success', status)
        except urllib.error.HTTPError as e:
            return ('http_error', e.code)
        except Exception as e:
            return ('error', str(e))
    
    # Send requests in batches
    batch_size = concurrent_requests
    total_batches = (min_requests + batch_size - 1) // batch_size
    
    for batch in range(total_batches):
        start_idx = batch * batch_size
        end_idx = min(start_idx + batch_size, min_requests)
        
        with concurrent.futures.ThreadPoolExecutor(max_workers=concurrent_requests) as executor:
            futures = [executor.submit(make_request, i) for i in range(start_idx, end_idx)]
            
            for future in concurrent.futures.as_completed(futures):
                result_type, result_value = future.result()
                if result_type == 'success':
                    success_count += 1
                elif result_type == 'http_error':
                    if 400 <= result_value < 500:
                        error_4xx += 1
                    elif 500 <= result_value < 600:
                        error_5xx += 1
                else:
                    other_errors += 1
        
        # Small delay between batches
        time.sleep(request_interval_ms / 1000)
        
        # Log progress
        if (batch + 1) % 10 == 0:
            print(f"Progress: {end_idx}/{min_requests} requests completed")
    
    total_requests = success_count + error_4xx + error_5xx + other_errors
    
    result = {
        'statusCode': 200,
        'body': json.dumps({
            'status': 'completed',
            'target_url': target_url,
            'total_requests': total_requests,
            'success_count': success_count,
            'error_4xx': error_4xx,
            'error_5xx': error_5xx,
            'other_errors': other_errors,
            'success_rate': f"{(success_count / total_requests * 100):.2f}%" if total_requests > 0 else "N/A"
        })
    }
    
    print(f"Result: {json.dumps(result['body'])}")
    
    # Return error if too many 5xx errors
    if error_5xx > min_requests * 0.1:  # More than 10% 5xx errors
        result['statusCode'] = 500
        result['body'] = json.dumps({
            'status': 'error',
            'reason': 'Too many 5xx errors detected',
            'error_5xx': error_5xx,
            'threshold': min_requests * 0.1
        })
    
    return result
