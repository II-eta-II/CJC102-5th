import json
import os
import time
import urllib.request
import urllib.error
import concurrent.futures

def handler(event, context):
    print(f"Received event: {json.dumps(event)}")
    
    # Environment variables
    target_url = os.environ.get('TARGET_URL', '')
    requests_per_second = int(os.environ.get('REQUESTS_PER_SECOND', '2'))
    pre_deploy_wait = int(os.environ.get('PRE_DEPLOY_WAIT_SEC', '120'))
    canary_duration = int(os.environ.get('CANARY_DURATION_SEC', '300'))
    full_deploy_wait = int(os.environ.get('FULL_DEPLOY_WAIT_SEC', '60'))
    
    # Override from event if provided
    target_url = event.get('target_url', target_url)
    
    if not target_url:
        return {'statusCode': 400, 'body': json.dumps({'error': 'TARGET_URL not configured'})}
    
    # Calculate total duration: pre_deploy + canary + full_deploy
    total_duration = pre_deploy_wait + canary_duration + full_deploy_wait
    
    print(f"Starting CONTINUOUS synthetic traffic")
    print(f"Target URL: {target_url}")
    print(f"Requests per second: {requests_per_second}")
    print(f"Total duration: {total_duration} seconds")
    print(f"  - Pre-deploy wait: {pre_deploy_wait}s")
    print(f"  - Canary duration: {canary_duration}s")
    print(f"  - Full deploy wait: {full_deploy_wait}s")
    
    success_count = 0
    error_4xx = 0
    error_5xx = 0
    other_errors = 0
    start_time = time.time()
    
    def make_request():
        try:
            req = urllib.request.Request(target_url, headers={'User-Agent': 'SyntheticTrafficLambda/1.0'})
            with urllib.request.urlopen(req, timeout=30) as response:
                return ('success', response.getcode())
        except urllib.error.HTTPError as e:
            return ('http_error', e.code)
        except Exception as e:
            return ('error', str(e))
    
    # Send requests continuously until total_duration is reached
    request_interval = 1.0 / requests_per_second
    last_log_time = start_time
    
    while True:
        elapsed = time.time() - start_time
        
        # Check if we've reached the total duration
        if elapsed >= total_duration:
            break
        
        # Check if Lambda is about to timeout (leave 10s buffer)
        remaining_time = context.get_remaining_time_in_millis() / 1000
        if remaining_time < 10:
            print(f"Lambda timeout approaching, stopping early at {elapsed:.0f}s")
            break
        
        # Make request
        result_type, result_value = make_request()
        if result_type == 'success':
            success_count += 1
        elif result_type == 'http_error':
            if 400 <= result_value < 500:
                error_4xx += 1
            elif 500 <= result_value < 600:
                error_5xx += 1
        else:
            other_errors += 1
        
        # Log progress every 30 seconds
        if time.time() - last_log_time >= 30:
            total_requests = success_count + error_4xx + error_5xx + other_errors
            print(f"Progress at {elapsed:.0f}s: {total_requests} requests, {success_count} success, {error_5xx} 5xx errors")
            last_log_time = time.time()
        
        # Wait for next request
        time.sleep(request_interval)
    
    total_requests = success_count + error_4xx + error_5xx + other_errors
    duration = time.time() - start_time
    
    result = {
        'statusCode': 200,
        'body': json.dumps({
            'status': 'completed',
            'target_url': target_url,
            'duration_seconds': round(duration, 2),
            'total_requests': total_requests,
            'success_count': success_count,
            'error_4xx': error_4xx,
            'error_5xx': error_5xx,
            'other_errors': other_errors,
            'requests_per_second': round(total_requests / duration, 2) if duration > 0 else 0,
            'success_rate': f"{(success_count / total_requests * 100):.2f}%" if total_requests > 0 else "N/A"
        })
    }
    
    print(f"Final Result: {result['body']}")
    return result
