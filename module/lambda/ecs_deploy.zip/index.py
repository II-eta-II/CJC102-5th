import boto3
import json
import os

def handler(event, context):
    print(f"Received event: {json.dumps(event)}")
    
    ecs = boto3.client('ecs')
    cluster_name = os.environ['ECS_CLUSTER_NAME']
    service_names = os.environ['ECS_SERVICE_NAMES'].split(',')
    
    results = []
    for service_name in service_names:
        service_name = service_name.strip()
        if not service_name:
            continue
            
        try:
            print(f"Forcing new deployment for service: {service_name}")
            response = ecs.update_service(
                cluster=cluster_name,
                service=service_name,
                forceNewDeployment=True
            )
            results.append({
                'service': service_name,
                'status': 'success',
                'deploymentId': response['service']['deployments'][0]['id']
            })
            print(f"Successfully triggered deployment for {service_name}")
        except Exception as e:
            print(f"Error updating service {service_name}: {str(e)}")
            results.append({
                'service': service_name,
                'status': 'error',
                'error': str(e)
            })
    
    return {
        'statusCode': 200,
        'body': json.dumps(results)
    }
