import boto3
import json
import os
import re

def handler(event, context):
    print(f"Received event: {json.dumps(event)}")
    
    ecs = boto3.client('ecs')
    elbv2 = boto3.client('elbv2')
    ecr = boto3.client('ecr')
    lambda_client = boto3.client('lambda')
    
    # Environment variables
    cluster_name = os.environ['ECS_CLUSTER_NAME']
    blue_service = os.environ['BLUE_SERVICE_NAME']
    green_service = os.environ['GREEN_SERVICE_NAME']
    listener_arn = os.environ['LISTENER_ARN']
    blue_tg_arn = os.environ['BLUE_TG_ARN']
    green_tg_arn = os.environ['GREEN_TG_ARN']
    ecr_repo_url = os.environ['ECR_REPO_URL']
    canary_deploy_lambda_arn = os.environ.get('CANARY_DEPLOY_LAMBDA_ARN', '')
    
    # Get image digest and repo name from ECR push event
    detail = event.get('detail', {})
    image_digest = detail.get('image-digest', '')
    repo_name = detail.get('repository-name', '')
    triggered_tag = detail.get('image-tag', 'latest')
    
    print(f"Triggered by tag: {triggered_tag}, digest: {image_digest}")
    
    # Find version tag (x.x.x format) for the same image digest
    image_tag = None
    if image_digest and repo_name:
        try:
            # Get all tags for this image digest
            response = ecr.describe_images(
                repositoryName=repo_name,
                imageIds=[{'imageDigest': image_digest}]
            )
            
            for image in response.get('imageDetails', []):
                tags = image.get('imageTags', [])
                print(f"Found tags for digest: {tags}")
                
                # Find version tag matching x.x.x pattern
                for tag in tags:
                    if re.match(r'^\d+\.\d+\.\d+$', tag):
                        image_tag = tag
                        print(f"Found version tag: {image_tag}")
                        break
                
                if image_tag:
                    break
        except Exception as e:
            print(f"Error looking up ECR tags: {e}")
    
    if not image_tag:
        print(f"No version tag (x.x.x) found for this image. Using triggered tag: {triggered_tag}")
        image_tag = triggered_tag
    
    print(f"Using image tag: {image_tag}")
    
    # Detect inactive environment (weight = 0)
    rules = elbv2.describe_rules(ListenerArn=listener_arn)['Rules']
    default_rule = next((r for r in rules if r['IsDefault']), None)
    
    if not default_rule:
        return {'statusCode': 500, 'body': 'No default rule found'}
    
    target_groups = default_rule['Actions'][0].get('ForwardConfig', {}).get('TargetGroups', [])
    
    inactive_env = None
    inactive_service = None
    
    for tg in target_groups:
        if tg['TargetGroupArn'] == blue_tg_arn and tg.get('Weight', 0) == 0:
            inactive_env = 'blue'
            inactive_service = blue_service
            break
        elif tg['TargetGroupArn'] == green_tg_arn and tg.get('Weight', 0) == 0:
            inactive_env = 'green'
            inactive_service = green_service
            break
    
    if not inactive_env:
        print("No inactive environment found (both have non-zero weight). Skipping deployment.")
        return {'statusCode': 200, 'body': json.dumps({'status': 'skipped', 'reason': 'no_inactive_env'})}
    
    print(f"Deploying to inactive environment: {inactive_env} (service: {inactive_service})")
    
    # Get current task definition for the inactive service
    service_desc = ecs.describe_services(cluster=cluster_name, services=[inactive_service])
    current_task_def_arn = service_desc['services'][0]['taskDefinition']
    
    # Get task definition details
    task_def = ecs.describe_task_definition(taskDefinition=current_task_def_arn)['taskDefinition']
    
    # Update container image with new tag
    new_image = f"{ecr_repo_url}:{image_tag}"
    for container in task_def['containerDefinitions']:
        if 'wordpress' in container['name'].lower() or container == task_def['containerDefinitions'][0]:
            old_image = container['image']
            container['image'] = new_image
            print(f"Updating container '{container['name']}' image: {old_image} -> {new_image}")
            break
    
    # Register new task definition (copy from existing, just change image)
    new_task_def = ecs.register_task_definition(
        family=task_def['family'],
        taskRoleArn=task_def.get('taskRoleArn', ''),
        executionRoleArn=task_def.get('executionRoleArn', ''),
        networkMode=task_def.get('networkMode', 'awsvpc'),
        containerDefinitions=task_def['containerDefinitions'],
        volumes=task_def.get('volumes', []),
        requiresCompatibilities=task_def.get('requiresCompatibilities', ['FARGATE']),
        cpu=task_def.get('cpu', '256'),
        memory=task_def.get('memory', '512')
    )
    
    new_task_def_arn = new_task_def['taskDefinition']['taskDefinitionArn']
    print(f"Registered new task definition: {new_task_def_arn}")
    
    # Update service to use new task definition
    response = ecs.update_service(
        cluster=cluster_name,
        service=inactive_service,
        taskDefinition=new_task_def_arn,
        forceNewDeployment=True
    )
    
    deployment_id = response['service']['deployments'][0]['id']
    print(f"Successfully triggered deployment for {inactive_service}: {deployment_id}")
    
    # Invoke canary_deploy Lambda (next step in pipeline)
    if canary_deploy_lambda_arn:
        print(f"Invoking canary_deploy Lambda: {canary_deploy_lambda_arn}")
        try:
            # Pass inactive_env info to canary_deploy
            canary_event = {
                'inactive_env': inactive_env,
                'image_tag': image_tag,
                'deployment_id': deployment_id,
                'original_event': event
            }
            lambda_client.invoke(
                FunctionName=canary_deploy_lambda_arn,
                InvocationType='Event',  # Async invoke
                Payload=json.dumps(canary_event)
            )
            print("canary_deploy Lambda invoked successfully")
        except Exception as e:
            print(f"Error invoking canary_deploy Lambda: {e}")
    
    return {
        'statusCode': 200,
        'body': json.dumps({
            'status': 'success',
            'environment': inactive_env,
            'service': inactive_service,
            'image_tag': image_tag,
            'task_definition': new_task_def_arn,
            'deployment_id': deployment_id,
            'next_step': 'canary_deploy'
        })
    }
